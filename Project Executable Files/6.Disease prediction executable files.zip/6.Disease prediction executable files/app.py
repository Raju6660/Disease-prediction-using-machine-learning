from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

# Load the model
model = pickle.load(open('model.pkl', 'rb'))

# Define routes
@app.route("/")
def home():
    return render_template('index.html')

@app.route('/details')
def details():
    return render_template('details.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Define the list of symptoms
    symptoms = ['itching', 'continuous_sneezing', 'joint_pain', 'vomiting',
       'spotting_ urination', 'fatigue', 'weight_loss', 'lethargy',
       'high_fever', 'sunken_eyes', 'sweating', 'headache', 'dark_urine',
       'nausea', 'loss_of_appetite', 'pain_behind_the_eyes', 'abdominal_pain',
       'diarrhoea', 'mild_fever', 'yellowing_of_eyes', 'swelled_lymph_nodes',
       'malaise', 'phlegm', 'congestion', 'chest_pain', 'fast_heart_rate',
       'irritation_in_anus', 'swollen_legs', 'puffy_face_and_eyes',
       'excessive_hunger', 'muscle_weakness', 'movement_stiffness',
       'weakness_of_one_body_side', 'bladder_discomfort', 'depression',
       'irritability', 'muscle_pain', 'red_spots_over_body',
       'abnormal_menstruation', 'increased_appetite', 'mucoid_sputum',
       'rusty_sputum', 'lack_of_concentration', 'receiving_blood_transfusion',
       'coma', 'history_of_alcohol_consumption', 'blood_in_sputum',
       'palpitations', 'inflammatory_nails', 'yellow_crust_ooze']

    if request.method == 'POST':
        input = [str(x) for x in request.form.values()]

        b = [0] * 50
        for x in range(0, 50):
            for y in input:
                if symptoms[x] == y:
                    b[x] = 1
        b = np.array(b)
        b = b.reshape(1, 50)
        prediction = model.predict(b)
        prediction = prediction[0]
        return render_template('results.html', prediction_text=" {}".format(prediction))

if __name__ == "__main__":
    app.run()
